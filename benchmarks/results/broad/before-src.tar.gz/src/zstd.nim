## Pure Nim Zstandard. No C libraries, subprocesses, or runtime dependencies.
## Binary data is represented by strings/openArray[char].
when sizeof(int) != 8:
  {.error: "zstd requires a 64-bit Nim target".}
import zstd/[common, encode, decode]
export ZstdError, compress, decompress
